using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectManager : Singleton<ObjectManager>
{
    [SerializeField]
    private PoolDataSO[] poolDataArray;
    //private Dictionary<string, object> pools = new Dictionary<string, object>();
    //private Dictionary<PoolDataSO, object> tpools = new Dictionary<PoolDataSO, object>();
    private Dictionary<PoolDataSO, object> pools = new Dictionary<PoolDataSO, object>();

    public void CreatePool<T>(T prefab, PoolDataSO data, int size = 10) where T : MonoBehaviour, IPoolable
    {
        var pool = new GenericObjectPool<T>(prefab, size, this.transform);
        if (!pools.ContainsKey(data))
        {
            pools.Add(data, pool);
        }
    }

    public T Get<T>() where T : MonoBehaviour, IPoolable
    {
        if (pools.TryGetValue(, out object obj) && obj is GenericObjectPool<T> pool)
        {
            return pool.Get();
        }

        return null;
    }

    public void Return<T>(T item) where T : MonoBehaviour, IPoolable
    {
        if (pools.TryGetValue(key, out object obj) && obj is GenericObjectPool<T> pool)
        {
            pool.Return(item);
        }
        else
        {
            Debug.LogError($"Pool for {key} not found");
        }
    }

    override protected void Awake()
    {
        InitializePools(poolDataArray);
    }
    public void InitializePools(PoolDataSO[] poolDataList)
    {
        foreach (var data in poolDataList)
        {
            //var comp = data.prefab.GetComponent<IPoolable>();
            //comp.GetType().Name

            var componentType = data.componentToPool.GetType();
            var createPoolMethod = typeof(ObjectManager).GetMethod(nameof(CreatePool)).MakeGenericMethod(componentType);

            var component = data.prefab.GetComponent(componentType);

            createPoolMethod.Invoke(this, new object[] {component, data, data.initSize });


            //if (string.IsNullOrEmpty(data.poolKey) || data.prefab == null)
            //{
            //    Debug.LogWarning($"Ǯ ������ ����: {data.name}");
            //    continue;
            //}

            //if (!pools.ContainsKey(data.poolKey))
            //{
            //    var mono = data.prefab.GetComponent<IPoolable>();
            //    if (mono == null)
            //    {
            //        Debug.LogError($"Prefab '{data.prefab.name}'�� IPoolable�� �������� ����");
            //        continue;
            //    }
            //    var componentType = Type.GetType(data.componentTypeName);
            //    if (componentType == null)
            //    {
            //        Debug.LogError($"'{data.componentTypeName}' Ÿ���� ã�� �� ����");
            //        continue;
            //    }
            //    var createPoolMethod = typeof(ObjectManager).GetMethod(nameof(CreatePool)).MakeGenericMethod(componentType);

            //    var component = data.prefab.GetComponent(componentType);
                
            //    createPoolMethod.Invoke(this, new object[] { data.poolKey, component, data.initSize });
            //}
        }
    }
}
